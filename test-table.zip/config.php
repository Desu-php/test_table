<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'bot_stat');
define('DB_USER', 'root');
define('DB_PASSWORD', 'root');
