<?php


namespace core;


abstract class Controller
{

}
